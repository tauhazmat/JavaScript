document.write("<h1>Hello <span style=color:green>JavaScript</span> Planet</h1>")

document.write("<p>I am the <b>master</b> of my own fate.</p>")

document.write("<p>I am the <b>champion</b> of my own soul.</p>")

document.write("<p>I am the <b>superhero</b> of my own life.</p>")
